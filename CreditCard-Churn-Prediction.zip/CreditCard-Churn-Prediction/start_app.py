#!/usr/bin/env python
import subprocess
import sys
import os

# Change to the project directory
project_dir = r"C:\Users\TUPIEN\Downloads\CreditCard-Churn-Prediction-20260604T032513Z-3-001\CreditCard-Churn-Prediction"
os.chdir(project_dir)

# Run streamlit
subprocess.run([sys.executable, "-m", "streamlit", "run", "app/app.py"])
