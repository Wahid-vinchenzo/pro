import streamlit as st
import pandas as pd
import joblib

st.set_page_config(
    page_title="Credit Card Churn Prediction",
    page_icon="💳",
    layout="wide"
)

# =====================
# LOAD ARTIFACTS
# =====================

model = joblib.load(
    "models/credit_card_churn_lgbm_model_.pkl"
)

scaler = joblib.load(
    "models/scaler.pkl"
)

encoded_features = joblib.load(
    "models/encoded_features.pkl"
)

debug = st.sidebar.checkbox(
    "Show Debug Information"
)
# =====================
# TITLE
# =====================

st.title("💳 Credit Card Customer Churn Prediction")

st.markdown("""
This application uses a tuned LightGBM model
to predict customer churn risk based on
transaction behavior, account activity,
and customer profile information.
""")

# =====================
# INPUTS
# =====================

st.sidebar.header("Customer Information")

customer_age = st.sidebar.slider(
    "Customer Age",
    18,
    80,
    40
)

dependent_count = st.sidebar.slider(
    "Dependent Count",
    0,
    5,
    1
)

months_on_book = st.sidebar.slider(
    "Months on Book",
    6,
    60,
    24
)

total_relationship_count = st.sidebar.slider(
    "Relationship Count",
    1,
    6,
    3
)

months_inactive = st.sidebar.slider(
    "Months Inactive",
    0,
    6,
    2
)

contacts = st.sidebar.slider(
    "Contacts Count",
    0,
    6,
    2
)

credit_limit = st.sidebar.number_input(
    "Credit Limit",
    1000,
    50000,
    8000
)

total_revolving_bal = st.sidebar.number_input(
    "Revolving Balance",
    0,
    5000,
    1000
)

total_trans_amt = st.sidebar.number_input(
    "Total Transaction Amount",
    100,
    20000,
    4000
)

total_trans_ct = st.sidebar.number_input(
    "Transaction Count",
    1,
    150,
    60
)

# =====================
# CATEGORICALS
# =====================

gender = st.sidebar.selectbox(
    "Gender",
    ["M", "F"]
)

education = st.sidebar.selectbox(
    "Education",
    [
        "Graduate",
        "High School",
        "Uneducated",
        "Unknown",
        "College",
        "Post-Graduate",
        "Doctorate"
    ]
)

marital = st.sidebar.selectbox(
    "Marital Status",
    [
        "Married",
        "Single",
        "Unknown",
        "Divorced"
    ]
)

income = st.sidebar.selectbox(
    "Income Category",
    [
        "Less than $40K",
        "$40K - $60K",
        "$60K - $80K",
        "$80K - $120K",
        "$120K +",
        "Unknown"
    ]
)

card = st.sidebar.selectbox(
    "Card Category",
    [
        "Blue",
        "Silver",
        "Gold",
        "Platinum"
    ]
)
transaction_change = st.sidebar.slider(
    "Transaction Count Change (Q4/Q1)",
    0.0,
    5.0,
    1.0
)

amount_change = st.sidebar.slider(
    "Transaction Amount Change (Q4/Q1)",
    0.0,
    5.0,
    1.0
)

predict = st.sidebar.button(
    "Predict Churn"
)

st.sidebar.subheader(
    "Model Information"
)

st.sidebar.info(
    """
    Model: Tuned LightGBM

    Accuracy: 97.1%

    ROC-AUC: 99.2%
    """
)
# -----------------------------------------
if predict:

    # =====================
    # BASE FEATURES
    # =====================

    input_data = pd.DataFrame({
        "Customer_Age":[customer_age],
        "Dependent_count":[dependent_count],
        "Months_on_book":[months_on_book],
        "Total_Relationship_Count":[total_relationship_count],
        "Months_Inactive_12_mon":[months_inactive],
        "Contacts_Count_12_mon":[contacts],
        "Credit_Limit":[credit_limit],
        "Total_Revolving_Bal":[total_revolving_bal],
        "Total_Amt_Chng_Q4_Q1":[amount_change],
        "Total_Trans_Amt":[total_trans_amt],
        "Total_Trans_Ct":[total_trans_ct],
        "Total_Ct_Chng_Q4_Q1":[transaction_change]
    })

    # =====================
    # FEATURE ENGINEERING
    # =====================

    input_data["Avg_Open_To_Buy"] = (
        input_data["Credit_Limit"]
        -
        input_data["Total_Revolving_Bal"]
    )

    input_data["Avg_Utilization_Ratio"] = (
    input_data["Total_Revolving_Bal"]
    /
    max(input_data["Credit_Limit"].iloc[0],1)
    )

    input_data["Avg_Transaction_Value"] = (
    input_data["Total_Trans_Amt"]
    /
    max(input_data["Total_Trans_Ct"].iloc[0], 1)
    )

    input_data["Credit_Usage_Ratio"] = (
    input_data["Total_Revolving_Bal"]
    /
    max(input_data["Credit_Limit"].iloc[0],1)
    )

    input_data["Transactions_Per_Month"] = (
    input_data["Total_Trans_Ct"]
    /
    max(input_data["Months_on_book"].iloc[0], 1)
    )

    # =====================
    # MANUAL ENCODING
    # =====================

    input_data["Gender_M"] = (
        1 if gender == "M" else 0
    )

    input_data["Education_Level_Doctorate"] = (
        1 if education == "Doctorate" else 0
    )

    input_data["Education_Level_Graduate"] = (
        1 if education == "Graduate" else 0
    )

    input_data["Education_Level_High School"] = (
        1 if education == "High School" else 0
    )

    input_data["Education_Level_Post-Graduate"] = (
        1 if education == "Post-Graduate" else 0
    )

    input_data["Education_Level_Uneducated"] = (
        1 if education == "Uneducated" else 0
    )

    input_data["Education_Level_Unknown"] = (
        1 if education == "Unknown" else 0
    )

    input_data["Marital_Status_Married"] = (
        1 if marital == "Married" else 0
    )

    input_data["Marital_Status_Single"] = (
        1 if marital == "Single" else 0
    )

    input_data["Marital_Status_Unknown"] = (
        1 if marital == "Unknown" else 0
    )

    input_data["Income_Category_$40K - $60K"] = (
        1 if income == "$40K - $60K" else 0
    )

    input_data["Income_Category_$60K - $80K"] = (
        1 if income == "$60K - $80K" else 0
    )

    input_data["Income_Category_$80K - $120K"] = (
        1 if income == "$80K - $120K" else 0
    )

    input_data["Income_Category_Less than $40K"] = (
        1 if income == "Less than $40K" else 0
    )

    input_data["Income_Category_Unknown"] = (
        1 if income == "Unknown" else 0
    )

    input_data["Card_Category_Gold"] = (
        1 if card == "Gold" else 0
    )

    input_data["Card_Category_Platinum"] = (
        1 if card == "Platinum" else 0
    )

    input_data["Card_Category_Silver"] = (
        1 if card == "Silver" else 0
    )

    # =====================
    # COLUMN ORDER
    # =====================

    input_data = input_data.reindex(
        columns=encoded_features,
        fill_value=0
    )

    if debug:
        st.write(
            "Input Shape:",
            input_data.shape
        )

        st.dataframe(
            input_data
        )


    # =====================
    # SCALING
    # =====================

    input_scaled = scaler.transform(
        input_data
    )

    # =====================
    # PREDICTION
    # =====================

    prediction = model.predict(
        input_scaled
    )[0]

    probability = model.predict_proba(
        input_scaled
    )[0][1]

    if debug:
        st.write(
            "Prediction:",
            prediction
        )

        st.write(
            "Probability:",
            probability
        )

        st.write(
            "Scaled Shape:",
            input_scaled.shape
        )
    
    # =====================
    # RESULTS
    # =====================

    st.markdown("---")

    st.subheader(
        "🔮 Prediction Result"
    )

    col1, col2 = st.columns(2)

    with col1:

        if probability >= 0.80:

            st.error(
                "🔴 HIGH CHURN RISK"
            )

        elif probability >= 0.30:

            st.warning(
                "🟡 MEDIUM CHURN RISK"
            )

        else:

            st.success(
                "🟢 LOW CHURN RISK"
            )

    with col2:

        st.metric(
            "Churn Probability",
            f"{probability:.2%}"
        )

    st.progress(
        float(probability)
    )
    #---------------------

    if probability >= 0.80:
        st.info(
            "Recommended Action: Immediate retention campaign."
        )

    elif probability >= 0.30:
        st.info(
            "Recommended Action: Monitor engagement and offer incentives."
        )

    else:
        st.info(
            "Recommended Action: Customer appears stable."
        )
    
    st.markdown("---")

    st.caption(
        "Built with Streamlit | LightGBM Model | SHAP Explainability"
    )
    