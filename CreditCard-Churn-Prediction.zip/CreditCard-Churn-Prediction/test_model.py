import joblib
import numpy as np

# Load the model and check it
model = joblib.load("models/credit_card_churn_lgbm_model_.pkl")
scaler = joblib.load("models/scaler.pkl")
encoded_features = joblib.load("models/encoded_features.pkl")

print("Model type:", type(model))
print("Model class:", model.__class__)
print("Has predict_proba:", hasattr(model, 'predict_proba'))
print("Number of features:", len(encoded_features))

# Check if we can call predict
try:
    # Create dummy input with correct shape
    X_dummy = np.random.randn(1, len(encoded_features))
    print("\nTrying prediction with shape:", X_dummy.shape)
    result = model.predict(X_dummy)
    print("Prediction result:", result)
    
    # Try predict_proba
    print("\nTrying predict_proba...")
    proba = model.predict_proba(X_dummy)
    print("Predict proba result:", proba)
except Exception as e:
    import traceback
    print("Error:", type(e).__name__)
    print("Message:", str(e))
    traceback.print_exc()
