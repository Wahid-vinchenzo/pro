"""Train and save a leakage-safe, cross-validated churn pipeline."""
from __future__ import annotations

import json
from pathlib import Path
import warnings

import joblib
import numpy as np
import pandas as pd
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline
from lightgbm import LGBMClassifier
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold, train_test_split
from sklearn.metrics import (
    accuracy_score, average_precision_score, balanced_accuracy_score,
    confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score,
)

from src.churn_pipeline import FeatureEngineer, TARGET_COLUMN, target_to_binary, make_preprocessor

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "raw" / "BankChurners.csv"
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "churn_pipeline.joblib"
METRICS_PATH = ROOT / "reports" / "evaluation_metrics.json"
RANDOM_STATE = 42


def main() -> None:
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")
    data = pd.read_csv(DATA_PATH)
    if TARGET_COLUMN not in data:
        raise ValueError(f"Target column {TARGET_COLUMN!r} not found in {DATA_PATH}")

    y = target_to_binary(data[TARGET_COLUMN])
    # Raw features are passed into the pipeline. FeatureEngineer explicitly drops
    # CLIENTNUM and all Naive Bayes target-derived columns before preprocessing.
    X = data.drop(columns=[TARGET_COLUMN])
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE
    )

    pipeline = Pipeline(steps=[
        ("features", FeatureEngineer()),
        ("preprocessor", make_preprocessor()),
        ("smote", SMOTE(random_state=RANDOM_STATE, k_neighbors=5)),
        ("classifier", LGBMClassifier(
            objective="binary", random_state=RANDOM_STATE, n_jobs=1,
            verbosity=-1, class_weight=None,
        )),
    ])
    param_distributions = {
        "classifier__n_estimators": [150, 250, 350, 500],
        "classifier__learning_rate": [0.02, 0.04, 0.06, 0.1],
        "classifier__num_leaves": [15, 31, 47, 63],
        "classifier__max_depth": [-1, 6, 10, 14],
        "classifier__min_child_samples": [10, 20, 30, 40],
        "classifier__subsample": [0.8, 0.9, 1.0],
        "classifier__colsample_bytree": [0.8, 0.9, 1.0],
    }
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=RANDOM_STATE)
    search = RandomizedSearchCV(
        estimator=pipeline,
        param_distributions=param_distributions,
        n_iter=8,
        scoring="average_precision",
        cv=cv,
        n_jobs=-1,
        refit=True,
        random_state=RANDOM_STATE,
        verbose=1,
        error_score="raise",
        return_train_score=False,
    )
    # SMOTE is a pipeline step, so it is fit independently inside each CV fold.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=UserWarning)
        search.fit(X_train, y_train)

    best_pipeline = search.best_estimator_
    probabilities = best_pipeline.predict_proba(X_test)[:, 1]
    predictions = (probabilities >= 0.5).astype("int8")
    metrics = {
        "test_accuracy": float(accuracy_score(y_test, predictions)),
        "test_balanced_accuracy": float(balanced_accuracy_score(y_test, predictions)),
        "test_precision": float(precision_score(y_test, predictions, zero_division=0)),
        "test_recall": float(recall_score(y_test, predictions, zero_division=0)),
        "test_f1": float(f1_score(y_test, predictions, zero_division=0)),
        "test_roc_auc": float(roc_auc_score(y_test, probabilities)),
        "test_pr_auc": float(average_precision_score(y_test, probabilities)),
        "test_confusion_matrix": confusion_matrix(y_test, predictions).tolist(),
        "best_cv_pr_auc": float(search.best_score_),
        "best_params": search.best_params_,
        "positive_class": "Attrited Customer",
        "decision_threshold": 0.5,
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(best_pipeline, MODEL_PATH, compress=3)
    METRICS_PATH.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"Saved fitted pipeline: {MODEL_PATH}")
    print(f"Saved evaluation metrics: {METRICS_PATH}")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
