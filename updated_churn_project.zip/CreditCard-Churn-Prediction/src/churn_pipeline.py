"""Shared feature engineering and training helpers for ChurnGuard."""
from __future__ import annotations

from typing import Iterable
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline as SklearnPipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

TARGET_COLUMN = "Attrition_Flag"
TARGET_POSITIVE_LABEL = "Attrited Customer"
LEAKAGE_PREFIX = "Naive_Bayes_Classifier_Attrition_Flag_"

CATEGORICAL_FEATURES = [
    "Gender", "Education_Level", "Marital_Status", "Income_Category", "Card_Category"
]
NUMERIC_FEATURES = [
    "Customer_Age", "Dependent_count", "Months_on_book",
    "Total_Relationship_Count", "Months_Inactive_12_mon", "Contacts_Count_12_mon",
    "Credit_Limit", "Total_Revolving_Bal", "Avg_Open_To_Buy",
    "Total_Amt_Chng_Q4_Q1", "Total_Trans_Amt", "Total_Trans_Ct",
    "Total_Ct_Chng_Q4_Q1", "Avg_Utilization_Ratio", "Transactions_Per_Month",
]
MODEL_FEATURES = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def engineer_features(data: pd.DataFrame) -> pd.DataFrame:
    """Build the same model features from raw data at training and inference time.

    Target-derived Naive Bayes columns and CLIENTNUM are always excluded. The
    utilization ratio is computed once from balance/limit to avoid duplicate
    revolving-credit ratios; Transactions_Per_Month uses months on book.
    """
    frame = data.copy()
    frame = frame.drop(columns=[c for c in frame.columns if c.startswith(LEAKAGE_PREFIX)], errors="ignore")
    frame = frame.drop(columns=["CLIENTNUM", "Credit_Usage_Ratio"], errors="ignore")

    required = [
        "Customer_Age", "Dependent_count", "Months_on_book", "Total_Relationship_Count",
        "Months_Inactive_12_mon", "Contacts_Count_12_mon", "Credit_Limit",
        "Total_Revolving_Bal", "Total_Amt_Chng_Q4_Q1", "Total_Trans_Amt",
        "Total_Trans_Ct", "Total_Ct_Chng_Q4_Q1", *CATEGORICAL_FEATURES,
    ]
    missing = [c for c in required if c not in frame.columns]
    if missing:
        raise ValueError("Missing required input columns: " + ", ".join(missing))

    credit_limit = pd.to_numeric(frame["Credit_Limit"], errors="coerce").clip(lower=0)
    revolving = pd.to_numeric(frame["Total_Revolving_Bal"], errors="coerce").clip(lower=0)
    months = pd.to_numeric(frame["Months_on_book"], errors="coerce").replace(0, np.nan)
    transactions = pd.to_numeric(frame["Total_Trans_Ct"], errors="coerce")

    frame["Avg_Open_To_Buy"] = credit_limit - revolving
    frame["Avg_Utilization_Ratio"] = (revolving / credit_limit.replace(0, np.nan)).replace([np.inf, -np.inf], np.nan)
    frame["Transactions_Per_Month"] = transactions / months
    # Keep only a known, deterministic feature contract and a stable order.
    return frame.reindex(columns=MODEL_FEATURES)


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Sklearn-compatible feature engineering transformer."""
    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        if not isinstance(X, pd.DataFrame):
            X = pd.DataFrame(X)
        return engineer_features(X)

    def get_feature_names_out(self, input_features=None):
        return np.asarray(MODEL_FEATURES, dtype=object)


def make_preprocessor() -> ColumnTransformer:
    numeric_pipe = SklearnPipeline([
        ("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = SklearnPipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, NUMERIC_FEATURES),
        ("categorical", categorical_pipe, CATEGORICAL_FEATURES),
    ], remainder="drop", verbose_feature_names_out=True)


def target_to_binary(y: Iterable) -> np.ndarray:
    """Map the source dataset's label strings to binary churn labels."""
    values = pd.Series(y).astype(str).str.strip()
    valid = {"Existing Customer", "Attrited Customer"}
    unexpected = sorted(set(values.unique()) - valid)
    if unexpected:
        raise ValueError(f"Unexpected target labels: {unexpected}")
    return (values == TARGET_POSITIVE_LABEL).astype("int8").to_numpy()
