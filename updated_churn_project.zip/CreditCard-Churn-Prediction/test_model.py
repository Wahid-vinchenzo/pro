"""Smoke tests for the saved pipeline and its feature contract."""
from pathlib import Path
import sys
import unittest

import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.churn_pipeline import engineer_features, LEAKAGE_PREFIX


class PipelineSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model_path = ROOT / "models" / "churn_pipeline.joblib"
        if not cls.model_path.exists():
            raise unittest.SkipTest("Model artifact missing; run python train_model.py first")
        cls.pipeline = joblib.load(cls.model_path)
        cls.sample = pd.read_csv(ROOT / "data" / "raw" / "BankChurners.csv").drop(columns=["Attrition_Flag"]).head(5)

    def test_engineering_drops_identifiers_and_leakage(self):
        engineered = engineer_features(self.sample)
        self.assertNotIn("CLIENTNUM", engineered.columns)
        self.assertFalse(any(c.startswith(LEAKAGE_PREFIX) for c in engineered.columns))
        self.assertNotIn("Credit_Usage_Ratio", engineered.columns)

    def test_transactions_per_month_contract(self):
        engineered = engineer_features(self.sample)
        expected = self.sample["Total_Trans_Ct"] / self.sample["Months_on_book"]
        pd.testing.assert_series_equal(engineered["Transactions_Per_Month"], expected.rename("Transactions_Per_Month"), check_names=True)

    def test_pipeline_predicts_probabilities(self):
        probabilities = self.pipeline.predict_proba(self.sample)
        self.assertEqual(probabilities.shape, (len(self.sample), 2))
        self.assertTrue(((probabilities >= 0) & (probabilities <= 1)).all())


if __name__ == "__main__":
    unittest.main()
