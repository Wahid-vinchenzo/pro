"""Streamlit UI for the fitted ChurnGuard pipeline, including live SHAP explanations."""
from __future__ import annotations

import json
from pathlib import Path
import sys

import joblib
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import shap
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

st.set_page_config(page_title="ChurnGuard | Customer Churn Intelligence", page_icon="💳", layout="wide")

st.markdown("""
<style>
:root { color-scheme: light; }
.block-container { padding-top: 1.4rem; padding-bottom: 2rem; max-width: 1400px; }
.hero { padding: 1.25rem 1.5rem; border-radius: 18px; background: linear-gradient(120deg,#102a43,#176b87); color: white; margin-bottom: 1rem; }
.hero h1 { margin: 0; font-size: 2.15rem; }
.hero p { margin: .45rem 0 0 0; opacity: .88; }
.metric-badge { border: 1px solid #dbe5ee; border-radius: 14px; padding: .8rem 1rem; background: #f8fbfd; min-height: 85px; }
.section-card { padding: .8rem 1rem .2rem 1rem; border: 1px solid #e3eaf0; border-radius: 14px; background: #fff; }
</style>
""", unsafe_allow_html=True)


@st.cache_resource(show_spinner="Loading trained churn pipeline…")
def load_pipeline():
    path = ROOT / "models" / "churn_pipeline.joblib"
    if not path.exists():
        raise FileNotFoundError(f"Trained model not found at {path}. Run `python train_model.py` first.")
    return joblib.load(path)


@st.cache_data(show_spinner=False)
def load_training_background() -> pd.DataFrame:
    path = ROOT / "data" / "raw" / "BankChurners.csv"
    if not path.exists():
        raise FileNotFoundError(f"Training data not found at {path}; it is used only as SHAP background data.")
    data = pd.read_csv(path)
    return data.drop(columns=["Attrition_Flag"], errors="ignore").sample(
        n=min(80, len(data)), random_state=42
    )


@st.cache_data(show_spinner=False)
def load_metrics() -> dict:
    path = ROOT / "reports" / "evaluation_metrics.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def local_explanation(pipeline, raw_row: pd.DataFrame):
    """Return model-specific SHAP contributions for the positive (churn) class."""
    features = pipeline.named_steps["features"]
    preprocessor = pipeline.named_steps["preprocessor"]
    classifier = pipeline.named_steps["classifier"]
    background_raw = load_training_background()
    background_features = features.transform(background_raw)
    background_matrix = preprocessor.transform(background_features)
    row_matrix = preprocessor.transform(features.transform(raw_row))
    feature_names = list(preprocessor.get_feature_names_out())
    explainer = shap.Explainer(classifier, background_matrix, feature_names=feature_names)
    explanation = explainer(row_matrix)
    values = np.asarray(explanation.values)
    # SHAP versions/models may return (rows, features, classes); class 1 is churn.
    if values.ndim == 3:
        values = values[:, :, 1]
    contributions = values[0].astype(float)
    return pd.DataFrame({"feature": feature_names, "impact": contributions}).assign(
        magnitude=lambda d: d["impact"].abs()
    ).sort_values("magnitude", ascending=False).head(12).sort_values("impact")


pipeline = None
try:
    pipeline = load_pipeline()
except Exception as exc:
    st.error(f"Unable to load the trained pipeline: {exc}")
    st.info("From the project root, install requirements and run `python train_model.py`, then restart the app.")
    st.stop()

st.markdown('<div class="hero"><h1>💳 ChurnGuard</h1><p>Customer retention intelligence · Fold-safe training · Live local explanations</p></div>', unsafe_allow_html=True)
metrics = load_metrics()
metric_cols = st.columns(4)
for col, label, key, fmt in [
    (metric_cols[0], "Test ROC–AUC", "test_roc_auc", ".3f"),
    (metric_cols[1], "Test PR–AUC", "test_pr_auc", ".3f"),
    (metric_cols[2], "Test recall", "test_recall", ".1%"),
    (metric_cols[3], "Test F1", "test_f1", ".3f"),
]:
    with col:
        value = metrics.get(key)
        rendered = format(value, fmt) if isinstance(value, (int, float)) else "Train model first"
        st.markdown(f'<div class="metric-badge"><div style="color:#526779;font-size:.85rem">{label}</div><div style="font-size:1.5rem;font-weight:700;color:#102a43">{rendered}</div></div>', unsafe_allow_html=True)

st.write("")
st.caption("Prediction support only: model output is an estimate, not a guarantee. Review thresholds and business costs before operational use.")

with st.form("customer_form"):
    st.subheader("Customer profile")
    profile, account, behavior = st.columns(3)
    with profile:
        st.markdown("**Demographics**")
        customer_age = st.slider("Age", 18, 80, 42)
        gender = st.selectbox("Gender", ["F", "M"])
        dependents = st.slider("Dependents", 0, 5, 2)
        education = st.selectbox("Education", ["Graduate", "High School", "Uneducated", "Unknown", "College", "Post-Graduate", "Doctorate"])
        marital = st.selectbox("Marital status", ["Married", "Single", "Unknown", "Divorced"])
        income = st.selectbox("Income category", ["Less than $40K", "$40K - $60K", "$60K - $80K", "$80K - $120K", "$120K +", "Unknown"])
        card = st.selectbox("Card category", ["Blue", "Silver", "Gold", "Platinum"])
    with account:
        st.markdown("**Account & credit**")
        months_on_book = st.slider("Months on book", 6, 60, 36)
        relationships = st.slider("Products / relationships", 1, 6, 3)
        credit_limit = st.number_input("Credit limit ($)", min_value=0.0, max_value=100000.0, value=12000.0, step=500.0)
        revolving_balance = st.number_input("Revolving balance ($)", min_value=0.0, max_value=100000.0, value=850.0, step=50.0)
        inactive_months = st.slider("Inactive months (last 12)", 0, 6, 1)
        contacts = st.slider("Contacts (last 12 months)", 0, 6, 2)
    with behavior:
        st.markdown("**Transaction behavior**")
        transaction_amount = st.number_input("Total transaction amount ($)", min_value=0.0, max_value=1000000.0, value=5200.0, step=100.0)
        transaction_count = st.number_input("Total transaction count", min_value=0, max_value=500, value=72, step=1)
        amount_change = st.slider("Transaction amount change (Q4/Q1)", 0.0, 5.0, 0.9, 0.1)
        count_change = st.slider("Transaction count change (Q4/Q1)", 0.0, 5.0, 1.2, 0.1)
    submitted = st.form_submit_button("🔎 Predict churn risk", type="primary", use_container_width=True)

if submitted:
    raw_input = pd.DataFrame([{
        "Customer_Age": customer_age,
        "Gender": gender,
        "Dependent_count": dependents,
        "Education_Level": education,
        "Marital_Status": marital,
        "Income_Category": income,
        "Card_Category": card,
        "Months_on_book": months_on_book,
        "Total_Relationship_Count": relationships,
        "Months_Inactive_12_mon": inactive_months,
        "Contacts_Count_12_mon": contacts,
        "Credit_Limit": credit_limit,
        "Total_Revolving_Bal": revolving_balance,
        "Total_Amt_Chng_Q4_Q1": amount_change,
        "Total_Trans_Amt": transaction_amount,
        "Total_Trans_Ct": transaction_count,
        "Total_Ct_Chng_Q4_Q1": count_change,
    }])
    if credit_limit > 0 and revolving_balance > credit_limit:
        st.warning("Revolving balance is greater than the credit limit. Verify these inputs before interpreting the result.")
    try:
        probability = float(pipeline.predict_proba(raw_input)[0, 1])
        prediction = int(probability >= 0.5)
        risk = "Higher churn likelihood" if prediction else "Lower churn likelihood"
        result_cols = st.columns([1.1, 1, 1.5])
        with result_cols[0]:
            st.metric("Estimated churn probability", f"{probability:.1%}")
        with result_cols[1]:
            st.metric("Model classification", "Likely to churn" if prediction else "Likely to stay")
        with result_cols[2]:
            st.markdown(f"### {'🔴' if prediction else '🟢'} {risk}")
            st.caption("Classification threshold: 50% (configurable after business validation).")

        gauge = go.Figure(go.Indicator(
            mode="gauge+number", value=probability * 100,
            number={"suffix": "%", "font": {"size": 28}},
            title={"text": "Churn probability"},
            gauge={"axis": {"range": [0, 100]}, "bar": {"color": "#e76f51" if prediction else "#2a9d8f"},
                   "steps": [{"range": [0, 30], "color": "#e8f5ee"}, {"range": [30, 70], "color": "#fff2d8"}, {"range": [70, 100], "color": "#fde8e7"}]},
        ))
        gauge.update_layout(height=260, margin={"l": 25, "r": 25, "t": 45, "b": 10})
        st.plotly_chart(gauge, use_container_width=True)

        with st.spinner("Calculating local SHAP explanation…"):
            explanation_df = local_explanation(pipeline, raw_input)
        chart = go.Figure(go.Bar(
            x=explanation_df["impact"], y=explanation_df["feature"], orientation="h",
            marker_color=np.where(explanation_df["impact"] >= 0, "#d95d39", "#2a9d8f"),
            hovertemplate="%{y}<br>SHAP impact: %{x:.4f}<extra></extra>",
        ))
        chart.add_vline(x=0, line_color="#667085", line_width=1)
        chart.update_layout(title="Local feature contributions for this prediction", xaxis_title="SHAP value (positive values push toward churn)", yaxis_title="", height=420, margin={"l": 15, "r": 15, "t": 60, "b": 45})
        st.plotly_chart(chart, use_container_width=True)
        st.caption("SHAP values show how each encoded feature moves the model output relative to its background data. They describe model behavior, not causation.")
        with st.expander("View engineered model inputs"):
            from src.churn_pipeline import engineer_features
            st.dataframe(engineer_features(raw_input), use_container_width=True)
    except Exception as exc:
        st.exception(exc)
