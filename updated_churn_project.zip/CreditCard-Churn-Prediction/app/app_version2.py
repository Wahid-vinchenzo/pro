"""Compatibility entry point; the maintained application is app/app.py."""
from pathlib import Path
import subprocess
import sys

if __name__ == "__main__":
    project_root = Path(__file__).resolve().parents[1]
    app_path = Path(__file__).resolve().with_name("app.py")
    raise SystemExit(subprocess.call([
        sys.executable, "-m", "streamlit", "run", str(app_path),
        "--server.headless=true",
    ], cwd=project_root))
