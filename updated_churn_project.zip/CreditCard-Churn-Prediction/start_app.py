"""Launch the Streamlit app from any current working directory."""
from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app" / "app.py"


def main() -> int:
    if not APP.exists():
        print(f"Streamlit app not found: {APP}", file=sys.stderr)
        return 2
    if importlib_missing_streamlit():
        print("Streamlit is not installed. Run: python -m pip install -r requirements.txt", file=sys.stderr)
        return 2
    command = [sys.executable, "-m", "streamlit", "run", str(APP)]
    return subprocess.call(command, cwd=ROOT)


def importlib_missing_streamlit() -> bool:
    try:
        import streamlit  # noqa: F401
        return False
    except ImportError:
        return True


if __name__ == "__main__":
    raise SystemExit(main())
